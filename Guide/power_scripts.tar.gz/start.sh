#!/bin/bash 
echo "Quito Core"
echo "Starting ..."
docker-compose up -d
echo "Quito Core: Running"
echo "To stop Quito Core enter: ./stop.sh"
