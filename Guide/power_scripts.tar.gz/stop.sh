#!/bin/bash 
echo "Quito Core"
echo "Stopping ..."
docker-compose down
echo "Quito Core: Stopped"
